package com.github.perschola;


public class TableUtilities {
    public static String getSmallMultiplicationTable() {
        return getMultiplicationTable(5);
    }

    public static String getLargeMultiplicationTable() {
        return getMultiplicationTable(10);
    }

    public static String getMultiplicationTable(int tableSize) {
        String output = "";
        for ( int operand1 = 1; operand1 <= tableSize; operand1++) {
            for ( int operand2 = 1; operand2 <= tableSize; operand2++) {
                String product = String.valueOf(operand1 * operand2);
                output += padLeft(product, 3) + " |";
                if ( isEndOfTable(operand2, tableSize) ){
                    output = output + "\n";
                }
            }
        }
        return output;
    }

    private static boolean isEndOfTable(int operand2, int tableSize) {
        return operand2 == tableSize;
    }

    private static String padLeft(String s, int n) {
        return String.format("%" + n + "s", s);
    }

}

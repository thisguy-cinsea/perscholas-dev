package com.github.perschola;

public class TriangleUtilities {

    public static String getTriangle(int numberOfRows) {
        String output = "";
        for ( int row = 1; row < numberOfRows; row++ ){
            for ( int column = 1; column <= row; column++) {
                if (column == row ){
                    output += "*\n";
                } else {
                    output += "*";
                }
            }
        }
        return output;
    }

    public static String getRow(int numberOfStars) {
        String output = "";
        for ( int i = 0; i < numberOfStars; i++) {
            output += "*";
        }
        return output;
    }

    public static String getSmallTriangle() {
        return getTriangle(5);
    }

    public static String getLargeTriangle() {
        return getTriangle(10);
    }
}

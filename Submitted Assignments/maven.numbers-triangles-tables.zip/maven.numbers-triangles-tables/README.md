# Leon's Loopy Lab
* Read each of the following `README` files and complete each of the asks.
    * [README-NumberUtilities.md](./README-NumberUtilities.md)
    * [README-TriangleUtilities.md](./README-TriangleUtilities.md)
    * [README-TableUtilities.md](./README-TableUtilities.md)
    





















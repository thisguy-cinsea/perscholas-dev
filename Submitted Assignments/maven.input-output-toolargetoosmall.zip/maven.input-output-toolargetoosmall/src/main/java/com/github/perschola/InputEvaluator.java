package com.github.perschola;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.stream.IntStream;

public class InputEvaluator {

    public static final int MAX_UNITS = 100;
    public static final int MIN_UNITS = 1;
    public static final int RANDOM_NUM = (int) getRandomIntegerBetweenRange(MIN_UNITS,MAX_UNITS);

    public void run() {
        int numOfGuesses[] = new int[MAX_UNITS];
        Integer input = null;
//        System.out.println("Integer between " + MIN_UNITS + " and " + MAX_UNITS +": RandomIntegerNumber = "+ RANDOM_NUM);

        while(true){
            try{
                while(true){
                    System.out.println("Please enter a number between " + MIN_UNITS + " and " + MAX_UNITS +": ");
                    Scanner myObj = new Scanner(System.in);
                    input = myObj.nextInt();
                    if(numInRange(input)){
                        if(!repeatedNumber(input, numOfGuesses)){
                            incrementAndCount(input, numOfGuesses);
                        };
                        if(isCorrect(input)){
                            System.out.println("Total Guesses: " + incrementAndCount(input, numOfGuesses));
                            break;
                        }
                    }
                }
                ;
                break;
            } catch (InputMismatchException | NumberFormatException ex){
                System.out.println("I said a number...");
            }
        }
    }

    private Boolean repeatedNumber(Integer input, int[] numOfGuesses) {
        Integer finalInput = input;
        boolean repeatedNumber = IntStream.of(numOfGuesses).anyMatch(x -> x == finalInput);
        if(repeatedNumber) {
            System.out.println("You have already tried that number, guess again!");
        }
        return repeatedNumber;
    }

    private int incrementAndCount(Integer input, int[] numOfGuesses) {
        for (int i = 0; i < numOfGuesses.length; i++) {
            if (numOfGuesses[i] == 0) {
                numOfGuesses[i] = input;
                return i;
            }
        }
        return numOfGuesses.length;
    }

    private boolean isCorrect(Integer input) {
        if(input == RANDOM_NUM){
            System.out.println("Correct!");
            return true;
        } else if(input > RANDOM_NUM){
            System.out.println("too HIGH!");
        } else{
            System.out.println("too LOW!");
        }
        return false;
    }

    private boolean numInRange(Integer input) {
        return (input >= MIN_UNITS && input <= MAX_UNITS);
    }

    public static double getRandomIntegerBetweenRange(double min, double max){
        double x = (int)(Math.random()*((max-min)+1))+min;
        return x;
    }
}
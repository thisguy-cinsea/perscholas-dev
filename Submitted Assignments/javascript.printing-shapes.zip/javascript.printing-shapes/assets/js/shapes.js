function getLine(length) {
    // TODO - write method definition here
    if (length > 0){
        var shapeLength = "";
        for(var i = 0; i<length; i++ ){
            shapeLength = "*" + shapeLength;
        };
        return shapeLength.trim();
    };
}



function getBox(width, height) {
    // TODO - write method definition here
    var shapeLength = "";
    for(var i = 1; i <= height; i++){
        if (width > 0){
            for(var j = 1; j<=width; j++ ){
                if(j == width){
                    shapeLength = shapeLength + "*\n";
                } else {
                    shapeLength = shapeLength + "*";
                }
            };
        };
    };
    return shapeLength.trim();

}



function getBottomLeftTriangle(length) {
    // TODO - write method definition here
    var shapeLength = "";
    for(var i = 1; i <= length; i++){
        for(var j = 1; j <= i; j++){
            shapeLength = shapeLength + "*";
        }
        shapeLength = shapeLength + "\n";
    }
    return shapeLength.trim();
}


function getUpperLeftTriangle(length) {
    // TODO - write method definition here
    var shapeLength = "";
    for(var i = 1; i <= length; i++){
        for(var j = length; j >= i; j--){
            shapeLength = shapeLength + "*";
        }
        shapeLength = shapeLength + "\n";
    }
    return shapeLength.trim();
}



function getPyramid(length) {
    // TODO - write method definition here
    var str = '';
    for (var i = 0; i < length; i++) {
        
        for (var j = 1; j < length-i; j++) {
            str = str + ' ';
        }
        for (var k = 1; k <= (2*i+1); k++) {
            str = str + '*';
            if(k == (2*i+1)){
                str = str + "\n";
            }
        }
    }
    return str;
}


function getCheckerboard(width, height) {
    // TODO - write method definition here
    var gameboard = "";
    for( var i = 1; i <= height; i++){
        for( var j = 1; j <= width; j++) {
            if( isOdd(i) && isEven(j)){
                gameboard += "*";
            } else if ( isEven(i) && isOdd(j)) {
                gameboard += "*";
            } else {
                gameboard += " ";
            }
            if( j == width ){
                gameboard += "\n";
            }
        }
    }
    return gameboard;
}

function isOdd ( num){
    return (num % 2) != 0;
}

function isEven ( num){
    return (num % 2) == 0;
}


function compute(expression) {
    // TODO - write method definition here
    function checkOperators(regEx){
        for (var i = 0; i < expression.length; i++) {
            if(regEx.test(expression.charAt(i))){
                operator[operatori] = expression.charAt(i);
                location[operatori] = i;
                operatori++;
            }
        }
    };

    function getFirstOperand(regEx){
        if(regEx.test(expression.charAt(0))){
            if(location.length > 0){
                startOper = 0;
                for(var i = startOper; i< location[1]; i++){
                    operand1 += expression.charAt(i);
                }        
            } else {
                startOper = location[0];
                for(var i = startOper; i< location[0]; i++){
                    operand1 += expression.charAt(i);
                }        
            }
        } else{
            for(var i = 0; i <= location.length; i++){
                if((location[i] >= startOper) && (location[i] < location[0])){
                    startOper = location[i]+1;
                }
            }
            for(var i = startOper; i< location[0]; i++){
                operand1 += expression.charAt(i);
            }    
        }
    }

    function getSecondOperand(regEx){
        if(regEx.test(expression.charAt(0))){
            if(location.length > 0){
                for(var i = location[1]+1; i < expression.length; i++){
                    if(location[1] != 0){
                        if(regEx.test(expression.charAt(i))){
                            break;
                        } else{
                            operand2 += expression.charAt(i);
                        }
                        operator[0] = operator[1];
                    }
                }
            }
        } else {
            for(var i = location[0]+1; i < expression.length; i++){
                if(location[0] != 0){
                    if(regEx.test(expression.charAt(i))){
                        break;
                    } else{
                        operand2 += expression.charAt(i);
                    }
                }
            }
        }
    }

    function calc(){
        if(operand1 != ""){
            switch (operator[0]){
                case "\*": {
                    output = Number(operand1) * Number(operand2);
                    break; 
                }
                case "\/": {
                    output = Number(operand1) / Number(operand2);
                    newEx = operand1 / operand2;
                    break;
                }
                case "\+": {
                    output = Number(operand1) + Number(operand2);
                    newEx = operand1 + operand2;
                    break;
                }
                case "\-": {
                    output = Number(operand1) - Number(operand2);
                    newEx = operand1 - operand2;
                    break;
                }
            }
        }
        newEx = operand1 + operator[0] + operand2;
        newStr = expression.replace(newEx, output);
    }

    do{
        let reMulti = new RegExp(/[*/]/);
        let reAdd = new RegExp(/[+-]/);
        let reOper = new RegExp(/[*+/-]/);
        
        var operand1 = "";
        var operand2 = "";
        var location = [];
        var operator = [];
        var operatori = 0;
        var output;
        var newEx = 0;
        var startOper = 0;
    
    
    
        checkOperators(reMulti);
        checkOperators(reAdd);
        getFirstOperand(reOper);
        getSecondOperand(reOper);
        calc();
    
        if(operand1 == ""){
            break;
        }
        expression = newStr;
    } while (location.length>0);

    var person = { firstName: "John", lastName: "Doe", age: 50, eyeColor: "blue" }; for(var i in person){ console.log(i); }

    return output;
}

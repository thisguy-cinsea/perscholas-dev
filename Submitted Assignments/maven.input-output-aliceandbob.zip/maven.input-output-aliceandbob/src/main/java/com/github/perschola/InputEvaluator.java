package com.github.perschola;

import java.util.Scanner;

public class InputEvaluator {
    public void run() {
        // prompt user to input name
        Scanner myObj = new Scanner(System.in);
        // get name input from user
        System.out.println("Enter your name");
        String userName = myObj.nextLine();

        // evaluate name input from user
        if ("bob".equals(userName.toLowerCase()) | "alice".equals(userName.toLowerCase())){
            if(userName.toLowerCase().equals("bob")){
                System.out.println("Welcome, Bob!");
            } else {
                System.out.println("Welcome, Alice!");
            }
        } else{
            System.out.println("Stranger danger!");
        }
            // if name is not "Alice" nor "Bob"
                // display "Stranger danger!" to console
            // if name is "Alice"
                // display "Welcome, Alice!"
            // if name is "Bob"
                // display "Welcome, Bob!"
    }
}

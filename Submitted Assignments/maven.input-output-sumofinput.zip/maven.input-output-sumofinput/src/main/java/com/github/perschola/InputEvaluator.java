package com.github.perschola;

import java.util.InputMismatchException;
import java.util.Scanner;

public class InputEvaluator {
    public void run() {
        // prompt user to input number
        Integer input = null;
        while(true){
            try{
                while(true){
                    System.out.println("Please enter a number between 1 and 10: ");
                    Scanner myObj = new Scanner(System.in);
                    input = myObj.nextInt();
                    if(input > 0 && input <= 10){
                        System.out.println("Sum of " + input + " is " + getSum(input));
                        break;
                    }
                }
                break;
            } catch (InputMismatchException | NumberFormatException ex){
                System.out.println("I said a number...");
            }
        }
    }

    private Integer getSum(Integer input) {
        Integer output = 1;
        for (int i = 1; i <= input; i++) {
            output = i + output;
        }

        return output;
    }
}

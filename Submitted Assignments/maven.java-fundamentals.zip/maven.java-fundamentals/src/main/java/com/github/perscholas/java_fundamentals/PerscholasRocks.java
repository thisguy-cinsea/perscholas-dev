package com.github.perscholas.java_fundamentals;

/**
 * Created by leon Hunter on 2/5/18.
 */
public class PerscholasRocks {
    public static void main(String[] args) {
         System.out.println("Perscholas Rocks!");
    }
}

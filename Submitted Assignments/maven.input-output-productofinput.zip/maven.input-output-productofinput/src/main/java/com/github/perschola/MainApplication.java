package com.github.perschola;

public class MainApplication {
    public static void main(String[] args) {
        InputEvaluator myObject = new InputEvaluator();
        myObject.run();
    }
}
